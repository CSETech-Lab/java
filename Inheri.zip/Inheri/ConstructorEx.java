class Person {
    Person() {
        System.out.println("Person constructor");
    } 
    Person(String name)
    {
        System.out.println("Person Constructor Created by :" +name);
    }
}

class Student extends Person {
    Student() {
        
        System.out.println("Student constructor");
    }
}

public class ConstructorEx {
    public static void main(String[] args) {
        Student s = new Student();
    }
}