class Grandfather {
    void property() {
        System.out.println("Grandfather's property");
    }
}

class Father extends Grandfather {
    void house() {
        System.out.println("Father's house");
    }
}

class Son extends Father {
    void bike() {
        System.out.println("Son's bike");
    }
}

public class MultiInheri{
    public static void main(String[] args) {
        Son s = new Son();
        s.property();
        s.house();
        s.bike();
    }
}