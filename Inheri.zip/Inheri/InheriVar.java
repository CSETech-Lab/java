class Person {
    String name = "Ravi";
    private int id=123;
}

class Student extends Person {
    int rollNo = 101;

    void display() {
        System.out.println(name);
        System.out.println(rollNo);
    }
}

public class InheriVar {
    public static void main(String[] args) {
        Student s = new Student();
        s.display();
    }
}